# Licious-Clone

These are the three technologies that we used to clone the website. 
while coming to that HTML and CSS are easy compared to JAVASCRIPT.
it is very tougher than the other technologies. by using CSS we make the website 
more pleasing as possible. There are a lot of efforts taken to implement these tactics
