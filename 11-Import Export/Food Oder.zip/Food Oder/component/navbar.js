function navbar(){
    return `<div id="navbar">
    <div id="">Home</div>
    <div><a href="food.html">Food</a></div>
    <div><a href="day.html">Special</a></div>
</div> `;

}

export default navbar;